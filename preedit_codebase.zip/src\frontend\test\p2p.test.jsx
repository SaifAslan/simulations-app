import { render, screen, fireEvent } from "@testing-library/react";
import Game from "../components/Game";
import { describe, it, expect, beforeEach, vi } from "vitest";

describe("Game Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(window, "alert").mockImplementation(() => {});
  });

  it("prevents submit without all selections", () => {
    render(<Game initialDays={35} />);

    // Make sure the button is not disabled
    const runButton = screen.getByRole("button", { name: /run!/i });

    expect(runButton).toBeDisabled();
  });

  it("disables truck and research buttons when not enough days left", () => {
    // Render the Game component with initial days set to 6 (less than 7 needed for truck/research)
    render(<Game initialDays={6} />);

    // Get all method buttons
    const pushcartButton = screen.getByRole("button", { name: /pushcart/i });
    const truckButton = screen.getByRole("button", { name: /truck/i });
    const researchButton = screen.getByRole("button", { name: /research/i });

    // Pushcart should still be enabled (only needs 1 day)
    expect(pushcartButton).not.toBeDisabled();

    // Truck and Research should be disabled (need 7 days)
    expect(truckButton).toBeDisabled();
    expect(researchButton).toBeDisabled();
  });
});
