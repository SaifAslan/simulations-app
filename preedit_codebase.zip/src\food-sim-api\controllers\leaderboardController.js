// controllers/leaderboardController.js
const Leaderboard = require('../models/Leaderboard');

exports.addScore = async (req, res) => {
  try {
    const { simulationId, score } = req.body;
    const leaderboardEntry = new Leaderboard({
      simulation: simulationId,
      user: req.userId,
      score
    });
    await leaderboardEntry.save();
    res.status(201).json(leaderboardEntry);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};