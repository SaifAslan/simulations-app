/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['www.skillshare.com'],
      },
};

export default nextConfig;
