// data/researchResults
const researchResults = {
  "Arts District": {
    "Ice cream": "Lorem ipsum dolor sit amet.",
    "Frozen yogurt": "Consectetur adipiscing elit.",
    "Smoothies": "Vivamus luctus urna sed urna.",
  },
  "Beach": {
    "Ice cream": "Ut labore et dolore magna aliqua.",
    "Frozen yogurt": "Fusce dapibus, tellus ac cursus commodo.",
    "Smoothies": "Curabitur blandit tempus porttitor.",
  },
  "City Market": {
    "Ice cream": "Praesent commodo cursus magna.",
    "Frozen yogurt": "Integer posuere erat a ante venenatis.",
    "Smoothies": "Maecenas faucibus mollis interdum.",
  },
  "Train station": {
    "Ice cream": "Morbi leo risus, porta ac consectetur.",
    "Frozen yogurt": "Donec ullamcorper nulla non metus.",
    "Smoothies": "Cras mattis consectetur purus sit amet.",
  },
  "University": {
    "Ice cream": "Aenean lacinia bibendum nulla sed consectetur.",
    "Frozen yogurt": "Etiam porta sem malesuada magna.",
    "Smoothies": "Nullam quis risus eget urna mollis.",
  },
  "Downtown": {
    "Ice cream": "Suspendisse potenti in faucibus orci luctus.",
    "Frozen yogurt": "Pellentesque habitant morbi tristique senectus.",
    "Smoothies": "Vivamus sagittis lacus vel augue.",
  },
};

export default researchResults;